#!/bin/bash

echo  "Ip to scan: "
read ip

sudo nmap -f $ip*
