import time
import tkinter
from tkinter import PhotoImage
from PIL import Image,ImageTk
root = tkinter.Tk()

def msg():
    print("getting credentials...")
    time.sleep(2)
    print("accessing to system...")
    time.sleep(2)
    print("revoke permissions...")
    time.sleep(2)
    print("shutting down firewall...")
    time.sleep(2)
    print("copying user information...")
    time.sleep(2)
    print("...10%")
    time.sleep(2)
    print("...50%")
    print("...75%")
    time.sleep(2)
    print("...100%")
    time.sleep(2)
    print("transferring data...")
    time.sleep(6)
    print("Es broma, no te estoy hackeando jaja o si? Lel")
    time.sleep(5)
    print("succesful transfer")
    print("target neutralized")

img = Image.open(r'C:\Users\fabia\Desktop\server.jpg')
img = ImageTk.PhotoImage(img)
button = tkinter.Button(root, image=img, text="button", command=msg)

button.pack()
root.mainloop()
